SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=false

REPLACE="
"
sleep 1
ui_print " ————————————————————————————————— "
  ui_print "  RENDER×BUFFER×GRAFIS 3.0     "
  ui_print " ———————————————————————————————— "
  ui_print "  --I-N-S-T-A-L-L-I-N-G-- "
  ui_print " Menu Termux "
  ui_print "-S-U-C-C-E-S-S-I-N-S-T-A-L-L-E-D-"
  ui_print "Joined My Channel For Next Update "
  ui_print " |||||||||||||||||||||||||||||||  "
  ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "

i_print "- Extracting module files"
mkdir -p $MODPATH/system/bin
unzip -o "$ZIPFILE" 'RBG' -d $MODPATH/system/bin >&2
chmod +x $MODPATH/system/bin/RBG