if [[ ! -f /data/media/0/RBG ]]; then
echo "su -c sh /data/adb/modules/RBG/system/bin/RBG" > /data/media/0/RBG
fi